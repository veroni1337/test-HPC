$(function() {

    let sidebarToggle = document.getElementById('sidebar-toggle')
    let sidebar = document.getElementById('sidebar')
  
    if (sidebarToggle) {
      sidebarToggle.addEventListener('click', function () {
        if (sidebar.classList.contains('active')) {
          sidebar.classList.remove('active')
        } else {
          sidebar.classList.add('active')
        }
      })
    }
  
    let close = document.getElementsByClassName('close')
  
    if (close) {
      for (let i = 0; i < close.length; i++) {
        const element = close[i];
        element.addEventListener('click', function () {
          element.parentElement.classList.remove('active')
        })
      }
    }
  
    let navbar = document.getElementById('navbar')
  
    console.log(document.body.scrollTop);
  
    window.onscroll = function () {
      "use strict"
      if (document.body.scrollTop >= 100 || document.documentElement.scrollTop >= 100) {
        navbar.classList.add('scrolled')
      } else {
        navbar.classList.remove('scrolled')
      }
      
    }
  });